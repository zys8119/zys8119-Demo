import{_,o as c,c as e}from"./index-ed26fb40.js";const s={},t={class:"404"};function o(n,a){return c(),e("div",t)}const d=_(s,[["render",o],["__scopeId","data-v-c8712c92"]]);export{d as default};
